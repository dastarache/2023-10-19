<?php  
// se incluye el archivo funciones 
include("funciones.php");
// se invoca la funcion de consulta 
echo jugar();




?>