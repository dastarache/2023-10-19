<?php 
    function consulta(){
        $salida=0;//inicializa la varible 
        $salida=10*2/2;//calcula el area del triangulo
    return $salida;// retorna la operacion 
}
   function jugar(){
        $salida=0;//inicializa la varible 
        $salida=45*3/2;//calcula el area del triangulo
    return $salida;// retorna la operacion 
   }
?>